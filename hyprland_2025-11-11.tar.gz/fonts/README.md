These fonts (except archcraft.ttf) are not created by me. The credit goes to the actual creators.

I've just included them in the archive so user can set things up quickly and easily.
